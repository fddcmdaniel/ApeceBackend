# Stuff

## install project

```bash
npm install
```


## Running for dev

```bash
npm run start:dev
```
