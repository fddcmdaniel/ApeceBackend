import cors from "cors";
import express from "express";
import session from "express-session";
import { Sequelize } from 'sequelize';
import { AppController } from "./controllers/AppController";
import { EventController } from "./controllers/EventController";
import { ModulesController } from "./controllers/ModulesController";
import { UserController } from "./controllers/UserController";
import { Candidates } from "./modals/Candidates";
import { DocumentTypes } from "./modals/DocumentTypes";
import { Event } from "./modals/Event";
import { Modules } from "./modals/Modules";
import { User } from "./modals/User";
import { Votes } from "./modals/Votes";

const main = async () => {

  const app = express();

  app.use(express.json());
  app.use(cors({ credentials: true, origin: "http://localhost:3000" }));
  app.use(session({ secret: 'teste', name: 'SessionID', saveUninitialized: false, resave: true }));

  const sequelize = new Sequelize("app_com_db", "sa", "Joao1234!", {
    dialect: "mssql",
    host: "jduart.ddns.net",
    port: 8080
  });

  try {
    await sequelize.authenticate();
    // sequelize.sync({ alter: true }) //alter database based on modals structure
    console.log('Connection has been established successfully.');
  } catch (error) {
    console.error(error);
    process.exit();
  }

  // Sequelize Models e associações
  const modals = [User, Modules, Event, DocumentTypes, Candidates, Votes];
  modals.forEach((modal) => modal.initialize(sequelize));
  //User.belongsToMany(Event, { through: 'users_events', foreignKey: 'id_user', timestamps: false })
  //Event.belongsToMany(User, { through: 'users_events', foreignKey: 'id_event', timestamps: false })
  //User.belongsTo(DocumentTypes, { as: 'DocType', foreignKey: 'id_doc' });
  //Event.hasMany(Candidates, { as: 'CandidatesEvent', foreignKey: 'id_event' })
  //Candidates.hasMany(Votes, { foreignKey: 'id_candidate' })

  // get all users GET /users
  // get user by GET /users/:id
  // create user POST /users
  // update
  //   just specif fields PATCH /users/:id
  //   entire object PUT /users/:id
  // delete user DELETE /users

  // Middlewares de autenticação
  // app.use((req: Request, res: Response, next: NextFunction) => {
  //   //@ts-ignore
  //   if (req.session.loggedIn === true) {
  //     next()
  //   } else if (req.path === '/users/authenticate') {
  //     next()
  //   } else {
  //     res.sendStatus(401)
  //   }
  // })

  // Modules
  app.post('/users/authenticate', ModulesController.authenticate);
  app.post('/modules', ModulesController.create);
  app.get('/modules', ModulesController.get);

  // Users
  app.get('/users', UserController.get)
  app.get('/users/logout', UserController.logout)
  app.get('/users/search', UserController.search)
  app.put('/users/update', UserController.update);
  app.put('/users/updatepassword', UserController.updatePassword);
  app.get('/users/doctypes', UserController.docTypes);

  // Eventos
  app.get('/users/events', EventController.usersEvents);
  app.get('/event/listvotes/:id', EventController.votesEvent);
  app.post('/event/vote', EventController.eventVote);
  app.get('/event/:id/votecheck', EventController.voteCheck);

  // App
  app.get('/convert', AppController.imageToText);

  app.listen(3001, function () {
    console.log("Server started on port 3001");
  })
}

main();

